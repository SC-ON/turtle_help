\#turtle\_help

It is a easy way of "turtle",which need some few scripts to draw
square,rectangle,triangle......so,turtle\_help will help with this sort
of things.

I'll make it more helpful in the future,thanks for supporting
